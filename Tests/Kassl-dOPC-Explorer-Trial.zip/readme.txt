dOPC products are Copyright (C) 2002-2016 of:
 
	Kassl GmbH
	Schmidtkuhlsweg 3
	27607 Langen (Germany)
	phone: +49 4743 911021
	fax  : +49 4743 911022
	http://www.kassl.de
	e-mail: support@kassl.de

All rights reserved.

Use our web site http://www.kassl.de
to order dOPC products or to download the latest versions.


dOPC Explorer
--------------

With dOPC Explorer you are able to connect 
to any OPC DA or OPC XML DA server. 

For further information check our help file:
dOPCExplorer.chm


Installation
------------

Extract all files from the Zip archive to any folder.
Start the program dOPCExplorer.exe from the folder 
to which it has been extracted.

Recommended folder is: C:\Program Files\Kassl\dOPCExplorer

If your computer is "OPC free", i.e. there is no OPC server
or OPC client installed, you also have to install OPC
Foundation's "OPC Core Components Redistributable".
 (http://www.opcfoundation.org
Menu: Download->Redistributables).

